## Show Customer Specs for PC Building Simulator (with speed mods)
Shows customer's PC specs attached to their job E-Mails for diagnose, fix and upgrade jobs so you know what to expect.
!! NOT COMPATIBLE WITH MY SPEED MODS SINCE IT OVERWRITES THE ASSEMBLY FILE, SO THERE IS A VERSION OF THIS WITH BOTH SPEED MODS ALREADY ENABLED AND ONE WITHOUT, THIS IS THE VERSION WITH THE SPEED MODS !!

## Install
1. Extract all files in the archive to the main directory of PC Building Simulator
2. If it asks you to overwrite files while extracting say "yes"

## Notes
Tested on PC Building Simulator version 0.8.2.0. Not compatible with any other mods that change the Assembly-CSharp-firstpass.dll. Fully compatible with all my unitypatcher mods for PCBS.